using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Xml.Linq;
using MdbDiffTool.Core;

namespace MdbDiffTool
{
    /// <summary>
    /// Провайдер для XML-конфигураций Тюрино (*.cfg).
    /// 
    /// Важно: эти *.cfg — это XML (не INI).
    /// Мы представляем их как набор "логических таблиц" для удобного diff.
    /// </summary>
    public sealed class CfgDatabaseProvider : IDatabaseProvider, IBatchDatabaseProvider, IFastRowHashProvider
    {
        private readonly object _sync = new object();

        // Кэш живёт ТОЛЬКО в рамках BeginBatch/EndBatch.
        private readonly Dictionary<string, ParsedCfg> _batchCache =
            new Dictionary<string, ParsedCfg>(StringComparer.OrdinalIgnoreCase);

        public List<string> GetTableNames(string connectionString)
        {
            // Список фиксированный (какие-то таблицы могут быть пустыми — это нормально).
            return new List<string>
            {
                "CFG_ProjectParams",
                "CFG_Boxes",
                "CFG_Crates",
                "CFG_Nets",
                "CFG_Devices",
                "CFG_DeviceSignals",
            };
        }

        public DataTable LoadTable(string connectionString, string tableName)
        {
            var parsed = TryGetFromBatch(connectionString);
            if (parsed == null)
            {
                // Вне batch читаем файл заново (кэш не держим намеренно).
                parsed = Parse(connectionString);
            }

            if (!parsed.Tables.TryGetValue(tableName, out var table) || table == null)
            {
                // Возвращаем пустую таблицу с именем — чтобы UI не падал.
                return new DataTable(tableName);
            }

            return table;
        }

        public string[] GetPrimaryKeyColumns(string connectionString, string tableName)
        {
            // Ключи должны существовать в схеме ВСЕГДА.
            switch (tableName)
            {
                case "CFG_ProjectParams":
                    return new[] { "Key" };

                case "CFG_Boxes":
                    return new[] { "boxIndex" };

                case "CFG_Crates":
                    // crateKey = логическая группа (без префикса объекта и без "- A<N>")
                    // crateOrdinal = порядковый номер в группе (стабильный мэппинг A2<->A4 как "обновить")
                    return new[] { "crateKey", "crateClass", "type", "crateOrdinal" };

                case "CFG_Nets":
                    return new[] { "netKey" };

                case "CFG_Devices":
                    // deviceKey — синтетический ключ для сопоставления между разными объектами
                    // (например, МНС.КЦ - A1.1 <-> ПТ.КЦ - A1.1). В UI его скрываем.
                    return new[] { "deviceKey" };

                case "CFG_DeviceSignals":
                    return new[] { "deviceKey", "signalName" };
            }

            return null;
        }

        public void ApplyRowChanges(
            string targetConnectionString,
            string tableName,
            string[] primaryKeyColumns,
            IEnumerable<RowPair> pairsToApply)
        {
            throw new NotSupportedException(
                "Провайдер CFG пока поддерживает только сравнение (чтение). Применение изменений не реализовано.");
        }

        public void ReplaceTable(string connectionString, string tableName, DataTable dataTable)
        {
            throw new NotSupportedException(
                "Провайдер CFG пока поддерживает только сравнение (чтение). Замена таблиц не реализована.");
        }

        public void DropTable(string connectionString, string tableName)
        {
            throw new NotSupportedException(
                "Провайдер CFG пока поддерживает только сравнение (чтение). Удаление таблиц не реализовано.");
        }

        // ---------- Batch cache ----------

        public void BeginBatch(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                return;

            lock (_sync)
            {
                if (_batchCache.ContainsKey(connectionString))
                    return;
            }

            var sw = Stopwatch.StartNew();
            var parsed = Parse(connectionString);
            sw.Stop();

            lock (_sync)
            {
                // Могли проиграть гонку, но не страшно.
                _batchCache[connectionString] = parsed;
            }

            var path = ExtractFilePath(connectionString);
            long size = 0;
            try { size = new FileInfo(path).Length; } catch { /* ignore */ }
            AppLogger.Info($"CFG: разобран файл и создан кэш. Файл '{path}', размер={size} байт, время={sw.ElapsedMilliseconds} мс.");
        }

        public void EndBatch(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                return;

            lock (_sync)
            {
                _batchCache.Remove(connectionString);
            }
        }

        // ---------- Fast hash ----------

        public ColumnInfo[] GetTableColumns(string connectionString, string tableName)
        {
            var parsed = TryGetFromBatch(connectionString) ?? Parse(connectionString);

            if (!parsed.Tables.TryGetValue(tableName, out var table) || table == null)
                return Array.Empty<ColumnInfo>();

            var cols = new ColumnInfo[table.Columns.Count];
            for (int i = 0; i < table.Columns.Count; i++)
            {
                var c = table.Columns[i];
                cols[i] = new ColumnInfo(c.ColumnName, c.DataType);
            }
            return cols;
        }

        public Dictionary<string, ulong> LoadKeyHashMap(
            string connectionString,
            string tableName,
            string[] keyColumns,
            ColumnInfo[] tableColumns,
            CancellationToken cancellationToken)
        {
            if (tableColumns == null || tableColumns.Length == 0)
                throw new ArgumentException("tableColumns пустой.", nameof(tableColumns));
            if (keyColumns == null || keyColumns.Length == 0)
                throw new ArgumentException("keyColumns пустой.", nameof(keyColumns));

            // Маппинг имя->ординал в МОДЕЛИ (tableColumns)
            var nameToOrdinal = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < tableColumns.Length; i++)
                nameToOrdinal[tableColumns[i].Name] = i;

            var keyOrdinals = keyColumns
                .Select(k => nameToOrdinal.TryGetValue(k, out var ord)
                    ? ord
                    : throw new InvalidOperationException($"Колонка ключа '{k}' не найдена в схеме таблицы '{tableName}'."))
                .ToArray();

            var hashOrdinals = Enumerable.Range(0, tableColumns.Length).ToArray();
            var expectedTypes = tableColumns.Select(c => c.DataType).ToArray();

            var parsed = TryGetFromBatch(connectionString) ?? Parse(connectionString);

            if (!parsed.Tables.TryGetValue(tableName, out var table) || table == null)
                return new Dictionary<string, ulong>(StringComparer.OrdinalIgnoreCase);

            // Маппинг имя->ординал в реальной DataTable (может не содержать всех колонок из tableColumns)
            var actualOrdinals = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < table.Columns.Count; i++)
                actualOrdinals[table.Columns[i].ColumnName] = i;

            var map = new Dictionary<string, ulong>(StringComparer.OrdinalIgnoreCase);
            var record = new ArrayDataRecord(tableColumns.Length);

            var rowNumber = 0;
            foreach (DataRow row in table.Rows)
            {
                cancellationToken.ThrowIfCancellationRequested();
                rowNumber++;

                for (int i = 0; i < tableColumns.Length; i++)
                {
                    var colName = tableColumns[i].Name;
                    if (actualOrdinals.TryGetValue(colName, out var ord))
                    {
                        record.Values[i] = NormalizeToStringOrNull(row[ord]);
                    }
                    else
                    {
                        record.Values[i] = null;
                    }
                }

                var key = RowHashing.BuildKey(record, keyOrdinals);
                var hash = RowHashing.ComputeRowHash(record, hashOrdinals, expectedTypes);
                map[key] = hash;
            }

            return map;
        }

        // ---------- Parsing ----------

        private ParsedCfg TryGetFromBatch(string connectionString)
        {
            lock (_sync)
            {
                return _batchCache.TryGetValue(connectionString, out var p) ? p : null;
            }
        }

        private static string ExtractFilePath(string connectionString)
        {
            // Формат: CfgXmlFile=...;
            const string prefix = "CfgXmlFile=";
            if (!connectionString.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException("Неверная строка подключения для CFG.");

            var cs = connectionString.Substring(prefix.Length);
            if (cs.EndsWith(";"))
                cs = cs.Substring(0, cs.Length - 1);

            return cs.Trim();
        }

        private static object NormalizeToStringOrNull(object value)
        {
            if (value == null || value == DBNull.Value) return null;
            return value.ToString();
        }

        private static ParsedCfg Parse(string connectionString)
        {
            var path = ExtractFilePath(connectionString);

            if (!File.Exists(path))
                throw new FileNotFoundException("Файл не найден.", path);

            XDocument doc;
            try
            {
                doc = XDocument.Load(path, LoadOptions.None);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    $"CFG: не удалось прочитать XML из файла '{path}'.", ex);
            }

            var root = doc.Root;
            if (root == null)
                throw new InvalidOperationException($"CFG: пустой XML в файле '{path}'.");

            // Встречались варианты <ConfiguratorOutput><Configuration>...</Configuration></ConfiguratorOutput>
            // и потенциально другие корни. Поддержим оба.
            var cfg = root.Name.LocalName == "Configuration"
                ? root
                : root.Element("Configuration") ?? root.Element("ConfigurationProject");

            if (cfg == null)
                throw new InvalidOperationException(
                    $"CFG: не найден узел <Configuration> (или <ConfigurationProject>) в файле '{path}'.");

            var tables = new Dictionary<string, DataTable>(StringComparer.OrdinalIgnoreCase);

            tables["CFG_ProjectParams"] = BuildProjectParamsTable(root, cfg);
            tables["CFG_Boxes"] = BuildBoxesTable(cfg);
            tables["CFG_Crates"] = BuildCratesTable(cfg);

            // Nets/Devices/Signals завязаны на обход дерева.
            var netsRows = new List<Dictionary<string, string>>();
            var devicesRows = new List<Dictionary<string, string>>();
            var signalsRows = new List<Dictionary<string, string>>();

            var netKeyUniq = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (var net in cfg.Elements("Net"))
            {
                TraverseNet(net, parentNetKey: null, parentDeviceName: null,
                    netsRows: netsRows,
                    devicesRows: devicesRows,
                    signalsRows: signalsRows,
                    netKeyUniq: netKeyUniq);
            }

            tables["CFG_Nets"] = BuildTableFromRows("CFG_Nets", netsRows);
            tables["CFG_Devices"] = BuildTableFromRows("CFG_Devices", devicesRows);
            tables["CFG_DeviceSignals"] = BuildTableFromRows("CFG_DeviceSignals", signalsRows);

            // Служебные колонки (ключи/связи), которые нужны для сопоставления, но обычно не интересны в UI.
            HideInGrid(tables["CFG_Nets"], "netKey");
            HideInGrid(tables["CFG_Nets"], "parentNetKey");
            HideInGrid(tables["CFG_Nets"], "parentDeviceName");

            HideInGrid(tables["CFG_Devices"], "netKey");
            HideInGrid(tables["CFG_Devices"], "parentDeviceName");
            HideInGrid(tables["CFG_Devices"], "parentNetKey");
            HideInGrid(tables["CFG_Devices"], "deviceKey");

            HideInGrid(tables["CFG_DeviceSignals"], "deviceKey");
            HideInGrid(tables["CFG_DeviceSignals"], "signalIndex");

            EnsureMandatoryColumns(tables);
            return new ParsedCfg(tables);
        }

        private static void EnsureMandatoryColumns(Dictionary<string, DataTable> tables)
        {
            // Гарантируем наличие PK-колонок, иначе ResolveKeyColumns вернёт PK и diff упадёт.
            EnsureColumns(tables, "CFG_ProjectParams", new[] { "Key", "Value" });
            EnsureColumns(tables, "CFG_Boxes", new[] { "boxIndex", "name", "type" });
            EnsureColumns(tables, "CFG_Crates", new[] { "boxName", "crateName", "crateKey", "crateClass", "type", "crateOrdinal" });
            EnsureColumns(tables, "CFG_Nets", new[] { "netKey" });
            EnsureColumns(tables, "CFG_Devices", new[] { "deviceKey", "deviceName" });
            EnsureColumns(tables, "CFG_DeviceSignals", new[] { "deviceKey", "deviceName", "signalName" });
        }

        private static void EnsureColumns(Dictionary<string, DataTable> tables, string tableName, string[] columns)
        {
            if (!tables.TryGetValue(tableName, out var t) || t == null)
            {
                t = new DataTable(tableName);
                tables[tableName] = t;
            }

            foreach (var c in columns)
            {
                if (!t.Columns.Contains(c))
                    t.Columns.Add(c, typeof(string));
            }
        }

        private static DataTable BuildProjectParamsTable(XElement root, XElement cfg)
        {
            var dt = new DataTable("CFG_ProjectParams");
            dt.Columns.Add("Key", typeof(string));
            dt.Columns.Add("Value", typeof(string));

            // version атрибут на <ConfiguratorOutput>
            var verAttr = root.Attribute("version")?.Value;
            if (!string.IsNullOrWhiteSpace(verAttr))
                dt.Rows.Add("file_version", verAttr);

            var pp = cfg.Element("ProjectParams");
            if (pp == null) return dt;

            foreach (var el in pp.Elements())
            {
                // Берём только простые скаляры.
                if (el.HasElements) continue;
                var key = el.Name.LocalName;
                var value = (el.Value ?? "").Trim();
                dt.Rows.Add(key, value);
            }

            return dt;
        }

        private static DataTable BuildBoxesTable(XElement cfg)
        {
            var rows = new List<Dictionary<string, string>>();

            foreach (var box in cfg.Elements("Box"))
            {
                var pc = box.Element("ParamsCommon");
                var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                if (pc != null)
                    AddScalarChildren(dict, pc);
                rows.Add(dict);
            }

            var dt = BuildTableFromRows("CFG_Boxes", rows);

            // Переименуем для единообразия PK (boxIndex) и обязательные колонки.
            // В XML имя поля уже "boxIndex", поэтому тут просто гарантируем наличие.
            if (!dt.Columns.Contains("boxIndex")) dt.Columns.Add("boxIndex", typeof(string));
            if (!dt.Columns.Contains("name")) dt.Columns.Add("name", typeof(string));
            if (!dt.Columns.Contains("type")) dt.Columns.Add("type", typeof(string));

            return dt;
        }

        private static DataTable BuildCratesTable(XElement cfg)
        {
            var rows = new List<Dictionary<string, string>>();

            // Для стабильного сопоставления ("A2" <-> "A4" как обновление) используем:
            //  - crateKey: базовое имя без префикса объекта и без суффикса "- A<N>"
            //  - crateOrdinal: порядковый номер внутри группы (crateKey + crateClass + type)
            // Это позволяет видеть переименования/перенумерации как "Отличается (обновить)",
            // а не как "удалить/добавить".
            var indexItems = new List<CrateIndexItem>();

            foreach (var box in cfg.Elements("Box"))
            {
                var boxName = box.Element("ParamsCommon")?.Element("name")?.Value ?? "";

                var crates = box.Element("Crates")?.Elements("Crate");
                if (crates == null) continue;

                foreach (var crate in crates)
                {
                    var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    dict["boxName"] = boxName;

                    var pc = crate.Element("ParamsCommon");
                    if (pc != null)
                        AddScalarChildren(dict, pc);

                    if (dict.TryGetValue("name", out var crateName))
                    {
                        dict["crateName"] = crateName;
                        dict.Remove("name");

                        var localName = StripObjectPrefix(crateName); // например "КЦ - A4"
                        var baseKey = StripCrateSlotSuffix(localName); // например "КЦ"
                        dict["crateKey"] = baseKey;
                    }

                    // crateOrdinal заполним после группировки.
                    if (!dict.ContainsKey("crateOrdinal"))
                        dict["crateOrdinal"] = "";

                    rows.Add(dict);

                    // Данные для сортировки/нумерации внутри группы.
                    var key = dict.TryGetValue("crateKey", out var ck) ? (ck ?? "") : "";
                    var crateClass = dict.TryGetValue("crateClass", out var cc) ? (cc ?? "") : "";
                    var type = dict.TryGetValue("type", out var tp) ? (tp ?? "") : "";
                    var localForSort = dict.TryGetValue("crateName", out var cn) ? StripObjectPrefix(cn ?? "") : "";

                    indexItems.Add(new CrateIndexItem(dict, key, crateClass, type, localForSort));
                }
            }

            // Нумеруем внутри каждой группы (crateKey + crateClass + type)
            foreach (var grp in indexItems
                         .GroupBy(x => x.GroupKey, StringComparer.OrdinalIgnoreCase))
            {
                int ordinal = 1;
                foreach (var item in grp
                             .OrderBy(x => x.SortSlot)
                             .ThenBy(x => x.SortName, StringComparer.OrdinalIgnoreCase))
                {
                    item.Row["crateOrdinal"] = ordinal.ToString(CultureInfo.InvariantCulture);
                    ordinal++;
                }
            }

            var dt = BuildTableFromRows("CFG_Crates", rows);
            if (!dt.Columns.Contains("boxName")) dt.Columns.Add("boxName", typeof(string));
            if (!dt.Columns.Contains("crateName")) dt.Columns.Add("crateName", typeof(string));
            if (!dt.Columns.Contains("crateKey")) dt.Columns.Add("crateKey", typeof(string));
            if (!dt.Columns.Contains("crateClass")) dt.Columns.Add("crateClass", typeof(string));
            if (!dt.Columns.Contains("type")) dt.Columns.Add("type", typeof(string));
            if (!dt.Columns.Contains("crateOrdinal")) dt.Columns.Add("crateOrdinal", typeof(string));

            // Служебные (синтетические) колонки скрываем в гриде, но оставляем в данных и PK.
            HideInGrid(dt, "crateKey");
            HideInGrid(dt, "crateOrdinal");

            return dt;
        }

        private sealed class CrateIndexItem
        {
            public readonly Dictionary<string, string> Row;
            public readonly string CrateKey;
            public readonly string CrateClass;
            public readonly string Type;
            public readonly string SortName;
            public readonly int SortSlot;

            public CrateIndexItem(Dictionary<string, string> row, string crateKey, string crateClass, string type, string sortName)
            {
                Row = row;
                CrateKey = crateKey ?? "";
                CrateClass = crateClass ?? "";
                Type = type ?? "";
                SortName = sortName ?? "";
                SortSlot = TryParseCrateSlot(sortName, out var n) ? n : int.MaxValue;
            }

            public string GroupKey => $"{CrateKey}|{CrateClass}|{Type}";
        }

        private static void TraverseNet(
            XElement net,
            string parentNetKey,
            string parentDeviceName,
            List<Dictionary<string, string>> netsRows,
            List<Dictionary<string, string>> devicesRows,
            List<Dictionary<string, string>> signalsRows,
            Dictionary<string, int> netKeyUniq)
        {
            if (net == null) return;

            var pc = net.Element("ParamsCommon");
            var ps = net.Element("ParamsSpecific");

            var netName = pc?.Element("name")?.Value ?? "";
            var baseKey = string.IsNullOrWhiteSpace(parentNetKey) ? netName : (parentNetKey + "|" + netName);
            if (string.IsNullOrWhiteSpace(baseKey)) baseKey = "(без имени)";

            // Уникализация ключа внутри файла.
            var netKey = MakeUniqueKey(baseKey, netKeyUniq);

            var netRow = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            netRow["netKey"] = netKey;
            netRow["parentNetKey"] = parentNetKey ?? "";
            netRow["parentDeviceName"] = parentDeviceName ?? "";

            if (pc != null) AddScalarChildren(netRow, pc);
            if (ps != null) AddScalarChildren(netRow, ps, prefix: "ps_");
            netsRows.Add(netRow);

            // Devices внутри net
            var devices = net.Element("Devices")?.Elements("Device");
            if (devices != null)
            {
                foreach (var dev in devices)
                {
                    TraverseDevice(dev, netKey, netsRows, devicesRows, signalsRows, netKeyUniq);
                }
            }
        }

        private static void TraverseDevice(
            XElement device,
            string parentNetKey,
            List<Dictionary<string, string>> netsRows,
            List<Dictionary<string, string>> devicesRows,
            List<Dictionary<string, string>> signalsRows,
            Dictionary<string, int> netKeyUniq)
        {
            var pc = device.Element("ParamsCommon");
            var ps = device.Element("ParamsSpecific");

            var deviceName = pc?.Element("name")?.Value ?? "";
            if (string.IsNullOrWhiteSpace(deviceName))
                deviceName = "(без имени)";

            // Нормализованный ключ для сопоставления между разными объектами
            // (например, "МНС.КЦ - A1.1" <-> "ПТ.КЦ - A1.1").
            var deviceKey = StripObjectPrefix(deviceName);
            if (string.IsNullOrWhiteSpace(deviceKey))
                deviceKey = "(без имени)";

            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            row["deviceKey"] = deviceKey;
            row["deviceName"] = deviceName;
            row["parentNetKey"] = parentNetKey ?? "";

            // Адресация (box/crate/slotNum)
            var addr = device.Element("Addressing");
            if (addr != null)
            {
                row["box"] = (addr.Element("box")?.Value ?? "").Trim();
                row["crate"] = (addr.Element("crate")?.Value ?? "").Trim();
                row["slotNum"] = (addr.Element("slotNum")?.Value ?? "").Trim();
            }

            if (pc != null)
            {
                AddScalarChildren(row, pc);
                // Чтобы не дублировать одно и то же двумя колонками (name и deviceName)
                // оставляем только deviceName.
                row.Remove("name");
            }

            // ParamsSpecific: берём скаляры, но исключаем signals (они идут в отдельную таблицу)
            if (ps != null)
            {
                foreach (var el in ps.Elements())
                {
                    var name = el.Name.LocalName;
                    if (string.Equals(name, "signals", StringComparison.OrdinalIgnoreCase))
                        continue;

                    if (el.HasElements) continue;
                    row["ps_" + name] = (el.Value ?? "").Trim();
                }
            }

            devicesRows.Add(row);

            // Signals
            var signals = ps?.Element("signals");
            if (signals != null)
            {
                foreach (var sig in signals.Elements())
                {
                    // Сигнал — это элемент вроде <_0 name="AIn[0]">...
                    var sigName = sig.Attribute("name")?.Value ?? sig.Name.LocalName;
                    var sigIndex = sig.Name.LocalName;

                    var srow = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                    {
                        ["deviceKey"] = deviceKey,
                        ["deviceName"] = deviceName,
                        ["signalName"] = sigName,
                        ["signalIndex"] = sigIndex,
                    };

                    // Внутри бывают Params + InputChannelParams/OutputChannelParams и т.п.
                    var p = sig.Element("Params");
                    if (p != null) AddScalarChildren(srow, p, prefix: "p_");

                    var inp = sig.Element("InputChannelParams");
                    if (inp != null) AddScalarChildren(srow, inp, prefix: "in_");

                    var outp = sig.Element("OutputChannelParams");
                    if (outp != null) AddScalarChildren(srow, outp, prefix: "out_");

                    // На всякий — остальные простые скаляры верхнего уровня сигнала
                    foreach (var el in sig.Elements())
                    {
                        var n = el.Name.LocalName;
                        if (n == "Params" || n == "InputChannelParams" || n == "OutputChannelParams")
                            continue;
                        if (el.HasElements) continue;
                        srow["sig_" + n] = (el.Value ?? "").Trim();
                    }

                    signalsRows.Add(srow);
                }
            }

            // Внутри устройства могут быть вложенные сети
            var nets = device.Element("Nets")?.Elements("Net");
            if (nets != null)
            {
                foreach (var net in nets)
                {
                    TraverseNet(net,
                        parentNetKey: parentNetKey,
                        parentDeviceName: deviceName,
                        netsRows: netsRows,
                        devicesRows: devicesRows,
                        signalsRows: signalsRows,
                        netKeyUniq: netKeyUniq);
                }
            }
        }

        private static string StripObjectPrefix(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return value;

            var s = value.Trim();
            var idx = s.IndexOf('.');
            if (idx <= 0 || idx >= s.Length - 1)
                return s;

            return s.Substring(idx + 1).Trim();
        }

        /// <summary>
        /// Убирает из строки суффикс вида " - A&lt;число&gt;" (если он есть).
        /// Пример: "КЦ - A4" -> "КЦ".
        /// </summary>
        private static string StripCrateSlotSuffix(string localName)
        {
            if (string.IsNullOrWhiteSpace(localName))
                return localName;

            var s = localName.Trim();

            // Ищем последний маркер "- A" и цифры в конце.
            // Поддержим варианты с пробелами: " - A4", "-A4", "- A 4" (на всякий).
            // Если не похоже — возвращаем как есть.
            int dash = s.LastIndexOf('-');
            if (dash < 0 || dash >= s.Length - 1)
                return s;

            var tail = s.Substring(dash + 1).Trim(); // например "A4"
            if (tail.Length < 2)
                return s;

            if (tail[0] != 'A' && tail[0] != 'a')
                return s;

            var numPart = tail.Substring(1).Trim();
            if (numPart.Length == 0)
                return s;

            if (!int.TryParse(numPart, NumberStyles.Integer, CultureInfo.InvariantCulture, out _))
                return s;

            // Удаляем "- A<число>" вместе с пробелами слева.
            return s.Substring(0, dash).Trim();
        }

        /// <summary>
        /// Пытается распарсить номер "A&lt;число&gt;" из конца строки.
        /// Пример: "КЦ - A4" -> 4.
        /// </summary>
        private static bool TryParseCrateSlot(string localName, out int slot)
        {
            slot = 0;
            if (string.IsNullOrWhiteSpace(localName))
                return false;

            var s = localName.Trim();
            int dash = s.LastIndexOf('-');
            if (dash < 0 || dash >= s.Length - 1)
                return false;

            var tail = s.Substring(dash + 1).Trim();
            if (tail.Length < 2)
                return false;
            if (tail[0] != 'A' && tail[0] != 'a')
                return false;

            var numPart = tail.Substring(1).Trim();
            return int.TryParse(numPart, NumberStyles.Integer, CultureInfo.InvariantCulture, out slot);
        }

        private static void HideInGrid(DataTable dt, string columnName)
        {
            if (dt == null || string.IsNullOrWhiteSpace(columnName))
                return;
            if (!dt.Columns.Contains(columnName))
                return;

            dt.Columns[columnName].ExtendedProperties["HideInGrid"] = true;
        }

        private static string MakeUniqueKey(string baseKey, Dictionary<string, int> uniq)
        {
            if (!uniq.TryGetValue(baseKey, out var n))
            {
                uniq[baseKey] = 1;
                return baseKey;
            }

            n++;
            uniq[baseKey] = n;
            return baseKey + "#" + n;
        }

        private static void AddScalarChildren(Dictionary<string, string> target, XElement parent, string prefix = "")
        {
            foreach (var el in parent.Elements())
            {
                if (el.HasElements) continue;
                var key = prefix + el.Name.LocalName;
                target[key] = (el.Value ?? "").Trim();
            }
        }

        private static DataTable BuildTableFromRows(string name, List<Dictionary<string, string>> rows)
        {
            var dt = new DataTable(name);

            if (rows == null || rows.Count == 0)
                return dt;

            // Собираем все колонки (в порядке первого появления)
            var colOrder = new List<string>();
            var colSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var r in rows)
            {
                if (r == null) continue;
                foreach (var k in r.Keys)
                {
                    if (colSet.Add(k))
                        colOrder.Add(k);
                }
            }

            foreach (var c in colOrder)
                dt.Columns.Add(c, typeof(string));

            foreach (var r in rows)
            {
                var dr = dt.NewRow();
                foreach (var kv in r)
                {
                    if (!dt.Columns.Contains(kv.Key))
                        dt.Columns.Add(kv.Key, typeof(string));
                    dr[kv.Key] = kv.Value ?? (object)DBNull.Value;
                }
                dt.Rows.Add(dr);
            }

            return dt;
        }

        /// <summary>
        /// Лёгкая обёртка над object[] чтобы можно было использовать RowHashing без DataTable/DataReader.
        /// </summary>
        private sealed class ArrayDataRecord : IDataRecord
        {
            public ArrayDataRecord(int fieldCount)
            {
                if (fieldCount <= 0) throw new ArgumentOutOfRangeException(nameof(fieldCount));
                Values = new object[fieldCount];
            }

            public object[] Values { get; }

            public int FieldCount => Values.Length;

            public object this[int i] => GetValue(i);

            public object this[string name] => throw new NotSupportedException();

            public bool GetBoolean(int i) => Convert.ToBoolean(GetValue(i), CultureInfo.CurrentCulture);

            public byte GetByte(int i) => Convert.ToByte(GetValue(i), CultureInfo.CurrentCulture);

            public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
                => throw new NotSupportedException();

            public char GetChar(int i) => Convert.ToChar(GetValue(i), CultureInfo.CurrentCulture);

            public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
                => throw new NotSupportedException();

            public IDataReader GetData(int i) => throw new NotSupportedException();

            public string GetDataTypeName(int i) => GetFieldType(i).Name;

            public DateTime GetDateTime(int i) => Convert.ToDateTime(GetValue(i), CultureInfo.CurrentCulture);

            public decimal GetDecimal(int i) => Convert.ToDecimal(GetValue(i), CultureInfo.CurrentCulture);

            public double GetDouble(int i) => Convert.ToDouble(GetValue(i), CultureInfo.CurrentCulture);

            public Type GetFieldType(int i)
            {
                var v = GetValue(i);
                return v == null || v is DBNull ? typeof(object) : v.GetType();
            }

            public float GetFloat(int i) => Convert.ToSingle(GetValue(i), CultureInfo.CurrentCulture);

            public Guid GetGuid(int i)
            {
                var v = GetValue(i);
                if (v is Guid g) return g;
                if (v is string s) return Guid.Parse(s);
                throw new InvalidCastException();
            }

            public short GetInt16(int i) => Convert.ToInt16(GetValue(i), CultureInfo.CurrentCulture);

            public int GetInt32(int i) => Convert.ToInt32(GetValue(i), CultureInfo.CurrentCulture);

            public long GetInt64(int i) => Convert.ToInt64(GetValue(i), CultureInfo.CurrentCulture);

            public string GetName(int i) => i.ToString(CultureInfo.InvariantCulture);

            public int GetOrdinal(string name) => throw new NotSupportedException();

            public string GetString(int i) => Convert.ToString(GetValue(i), CultureInfo.CurrentCulture);

            public object GetValue(int i) => Values[i];

            public int GetValues(object[] values)
            {
                if (values == null) throw new ArgumentNullException(nameof(values));
                var n = Math.Min(values.Length, Values.Length);
                Array.Copy(Values, values, n);
                return n;
            }

            public bool IsDBNull(int i)
            {
                var v = Values[i];
                return v == null || v is DBNull;
            }
        }

        private sealed class ParsedCfg
        {
            public ParsedCfg(Dictionary<string, DataTable> tables)
            {
                Tables = tables ?? new Dictionary<string, DataTable>(StringComparer.OrdinalIgnoreCase);
            }

            public Dictionary<string, DataTable> Tables { get; }
        }
    }
}